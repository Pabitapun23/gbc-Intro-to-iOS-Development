//
//  Pabita_PizzaApp.swift
//  Pabita_Pizza
//
//  Created by Pabita Pun on 2024-02-02.
//

import SwiftUI

@main
struct Pabita_PizzaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
